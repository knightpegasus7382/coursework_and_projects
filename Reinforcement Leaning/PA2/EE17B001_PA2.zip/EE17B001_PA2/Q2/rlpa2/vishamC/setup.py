from setuptools import setup

setup(name='visham_C',
      version='0.0.1',
      install_requires=['gym', 'numpy', 'pygame']
)
