import numpy as np
import gym
import Four_room
import random as rd
import matplotlib.pyplot as plt
from matplotlib import colors

import pandas as pd
env = gym.make('Four_room-v0')

rd.seed(30)
class option:
	def __init__(self,env,number):
		self.number = number
		if number == 4 or number==11:
			self.termination = [6,2]
		if number == 5 or number==6:
			self.termination = [3,6]
		if number ==7 or number ==8 :
			self.termination = [7,9]
		if number == 9 or number == 10:
			self.termination = [10,6]


		if number == 4:
			self.inits = env.room_1[:]
			self.inits.append([3,6])
		if number ==5:
			self.inits = env.room_1[:]
			self.inits.append([6,2])
		if number==6:
			self.inits = env.room_2[:]
			self.inits.append([7,9])
		if number==7:
			self.inits = env.room_2[:]
			self.inits.append([3,6])
		if number==8:
			self.inits = env.room_3[:]
			self.inits.append([10,6])
		if number==9:
			self.inits = env.room_3[:]
			self.inits.append([7,9])
		if number==10:
			self.inits = env.room_4[:]
			self.inits.append([6,2])
		if number==11:
			self.inits = env.room_4[:]
			self.inits.append([10,6])

	def play_option(self,env):
		R =0
		steps =0
		done = False
		if env.state not in self.inits:
			print(env.state)
			print(self.number)
			raise ValueError("state not allowed option")


		if self.termination in [[3,6],[10,6]]:
			while not done:
				step_done = False
				if not step_done and env.state[0] > self.termination[0]:
					_,r = env.step(3,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[0] < self.termination[0]:
					_,r = env.step(1,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[1] > self.termination[1]:
					_,r = env.step(2,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[1] < self.termination[1]:
					_,r = env.step(0,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if env.state == env.goal:
					return R,steps,True
				if env.state not in self.inits:
					return R,steps,False
				if env.state == self.termination:
					done = True
		
		else:
			while not done:
				step_done = False
				if not step_done and env.state[1] > self.termination[1]:
					_,r = env.step(2,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[1] < self.termination[1]:
					_,r = env.step(0,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[0] > self.termination[0]:
					_,r = env.step(3,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True
				if not step_done and env.state[0] < self.termination[0]:
					_,r = env.step(1,False)
					R = R + (env.gamma**steps) * r
					steps = steps+1
					step_done = True

				if env.state == env.goal:
					return R,steps,True
				if env.state not in self.inits:
					return R,steps,False
				if env.state == self.termination:
					done = True


		if env.state == env.goal:
			return R,steps,True
		else:
			return R,steps,False



def available_options(env,state):
	opts = [0,1,2,3]
	if state == env.hallway_1:
		opts.append(5)
		opts.append(10)
	elif state == env.hallway_2:
		opts.append(4)
		opts.append(7)
	elif state == env.hallway_3:
		opts.append(6)
		opts.append(9)
	elif state == env.hallway_4:
		opts.append(8)
		opts.append(11)
	elif state in env.room_1:
		opts.append(4)
		opts.append(5)
	elif state in env.room_2:
		opts.append(6)
		opts.append(7)
	elif state in env.room_3:
		opts.append(8)
		opts.append(9)
	elif state in env.room_4:
		opts.append(10)
		opts.append(11)
	return opts


print("Please Enter the Goal Number")
goal = int(input())
if goal ==1:
	env.goal = env.G1
elif goal==2:
	env.goal = env.G2

print("Enter 1 for Fixed initiation state and Zero for random initiation")
init = int(input())
if init ==1:
	env.fixed_initiation = True
else:
	env.fixed_initiation = False

state = env.reset()
options = [0,1,2,3]
for i in range(4,12):
	options.append(option(env,i))

runs = 40
episodes = 1000
alpha = 0.125
epsilon = 0.1/0.99
avg_q_table = np.zeros((13,13,12))
avg_steps = np.zeros((runs,episodes))

for i in range(runs):
	q_table = np.zeros((13,13,12))
	epsilon = 0.1
	for j in range(episodes):
		state = env.reset()
		#print(state)
		print("epside: "+ str(j))
		avg_steps[i,j] = 0
		done = False
		while not done:
			rnd = rd.random()
			current_state = env.state[:]
			#print(current_state)

			
			options_possible = available_options(env,current_state)
			#print(options_possible)
			if rnd < epsilon:
				currrent_option = rd.choice(options_possible)
				#print(options_possible,currrent_option)
			else:
				#currrent_option = np.random.choice(np.flatnonzero(q_table[env.state[0],env.state[1],options_possible] == q_table[env.state[0],env.state[1],options_possible].max()))
				
				stuff = []
				max_ = np.max(q_table[env.state[0],env.state[1],options_possible])

				for opt in options_possible:
					if q_table[env.state[0],env.state[1],opt] == max_:
						stuff.append(opt)
						max_ = q_table[env.state[0],env.state[1],opt]
				currrent_option =rd.choice(stuff)
				#print(options_possible,currrent_option)

			if currrent_option <4:
				steps = 1
				#print(env.state)
				_,R = env.step(currrent_option,False)

				new_options = available_options(env,env.state)
				q_table[current_state[0],current_state[1],currrent_option] += alpha*(R+(env.gamma*np.max(q_table[env.state[0],env.state[1],new_options])) -  q_table[current_state[0],current_state[1],currrent_option])
				avg_steps[i,j] += 1
				if env.state == env.goal:
					done = True
			else:
				#print("yes")
				#print(currrent_option)
				R,steps,done = options[currrent_option].play_option(env)
				new_options = available_options(env,env.state)
				avg_steps[i,j] += steps
				q_table[current_state[0],current_state[1],currrent_option] += alpha*(R+(env.gamma**steps)*np.max(q_table[env.state[0],env.state[1],new_options]) -  q_table[current_state[0],current_state[1],currrent_option])
		#print(avg_steps[i,j])
	avg_q_table += (q_table/runs)
	#print(avg_q_table)
temp = np.max(avg_q_table,axis=2)
pd.DataFrame(np.mean(avg_steps,axis=0)).to_csv("smdp_fixed_goal2.csv")



plt.loglog(np.mean(avg_steps,axis=0),label="SMDPQ")
plt.xlabel("Episodes")
plt.ylabel("Steps")
plt.title("Fixed Goal 2")
plt.show()














