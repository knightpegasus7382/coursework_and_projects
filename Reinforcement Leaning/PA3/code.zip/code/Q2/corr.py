import gym
import random

import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt


random.seed(31)
tf.random.set_random_seed(2)


class replay_buffer():
	def __init__(self,buffer_size = 1000000):
		self.buffer = []
		self.buffer_size = buffer_size
	def add(self,experience):
		if len(self.buffer) + len(experience) >= self.buffer_size:
			self.buffer[0:len(self.buffer) + len(experience) - self.buffer_size] =[]
		self.buffer.extend(experience)
	def sample(self,size):
		return np.reshape(np.array(random.sample(self.buffer,size)),[size,5])


class DQN:
		# Create and initialize the environment
	def __init__(self,env):

		self.env = gym.make(env)
		assert len(self.env.observation_space.shape) == 1
		self.input_size = self.env.observation_space.shape[0]		# In case of cartpole, 4 state features
		self.output_size = self.env.action_space.n					# In case of cartpole, 2 actions (right/left)
		self.REPLAY_MEMORY_SIZE = 100000		# number of tuples in experience replay  
		self.HIDDEN1_SIZE = 16
		self.HIDDEN2_SIZE = 16
		self.episodes_num = 2000
		self.MAX_STEPS = 200
		self.LEARNING_RATE = 0.0001
		self.min_epsilon=0.05
		self.DISCOUNT_FACTOR = 1
		self.LOG_DIR ="./logs"


		self.EPSILON = 0.5
		self.EPSILON_DECAY = 0.99
		self.MINIBATCH_SIZE = 128
		self.TARGET_UPDATE_FREQ = 100
	# Create the Q-network
	def initialize_network(self):

# placeholder for the state-space input to the q-network
		self.main_weights = {}
		self.target_weights = {}
		with tf.name_scope('output'):
			self.x = tf.placeholder(tf.float32, [None, self.input_size])
			self.main_weights['W_1'] = tf.Variable(tf.truncated_normal([self.input_size,self.HIDDEN1_SIZE],stddev=0.1),name = "W_1")
			self.main_weights['b_1'] = tf.Variable(tf.zeros(self.HIDDEN1_SIZE),name = "b_1")
			self.h_1 = tf.nn.relu(tf.matmul(self.x,self.main_weights['W_1']) +self.main_weights['b_1'])
			self.main_weights['W_2'] = tf.Variable(tf.truncated_normal([self.HIDDEN1_SIZE,self.HIDDEN2_SIZE],stddev=0.1),name = "W_2")
			self.main_weights['b_2'] = tf.Variable(tf.zeros(self.HIDDEN2_SIZE),name = "b_2")
			self.h_2 = tf.nn.relu(tf.matmul(self.h_1,self.main_weights['W_2']) + self.main_weights['b_2'])
			self.main_weights['W_3'] = tf.Variable(tf.truncated_normal([self.HIDDEN2_SIZE,self.output_size],stddev=0.1),name = "W_3")
			self.main_weights['b_3'] = tf.Variable(tf.zeros(self.output_size),name = "b_3")
			self.main_Qout = tf.matmul(self.h_2,self.main_weights['W_3']) + self.main_weights['b_3']
			self.main_predict = tf.argmax(self.main_Qout,axis=1)
			self.targetQ = tf.placeholder(tf.float32,[None])
			self.actions = tf.placeholder(tf.int32,[None])
			self.actions_onehot = tf.one_hot(self.actions,self.output_size,dtype=tf.float32)
			self.temp = tf.multiply(self.main_Qout,self.actions_onehot)
			self.Q = tf.reduce_sum(self.temp,axis=1)
			self.loss = tf.reduce_sum(tf.square(self.targetQ-self.Q)) 
			tf.summary.scalar('loss', self.loss)
			self.global_step = tf.Variable(0, name='global_step', trainable=False)
			self.train_op = tf.train.AdamOptimizer(learning_rate = self.LEARNING_RATE).minimize(self.loss,global_step=self.global_step)




			self.target_weights['W_1'] = tf.Variable(tf.truncated_normal([self.input_size,self.HIDDEN1_SIZE],stddev=0.1),name = "W_1")
			self.target_weights['b_1'] = tf.Variable(tf.zeros(self.HIDDEN1_SIZE),name = "b_1")
			self.h_1 = tf.nn.relu(tf.matmul(self.x,self.target_weights['W_1']) +self.target_weights['b_1'])
			self.target_weights['W_2'] = tf.Variable(tf.truncated_normal([self.HIDDEN1_SIZE,self.HIDDEN2_SIZE],stddev=0.1),name = "W_2")
			self.target_weights['b_2'] = tf.Variable(tf.zeros(self.HIDDEN2_SIZE),name = "b_2")
			self.h_2 = tf.nn.relu(tf.matmul(self.h_1,self.target_weights['W_2']) + self.target_weights['b_2'])
			self.target_weights['W_3'] = tf.Variable(tf.truncated_normal([self.HIDDEN2_SIZE,self.output_size],stddev=0.1),name = "W_3")
			self.target_weights['b_3'] = tf.Variable(tf.zeros(self.output_size),name = "b_3")
			self.target_Qout = tf.matmul(self.h_2,self.target_weights['W_3']) + self.target_weights['b_3']
			self.target_maxQ = tf.reduce_max(self.target_Qout,axis = 1)


	def train(self):

		summary_writer = tf.summary.FileWriter(self.LOG_DIR)	
		summary = tf.Summary()	

		episodes_num=self.episodes_num

		self.session = tf.Session()
		self.session.run(tf.global_variables_initializer())
		self.replay = replay_buffer(self.REPLAY_MEMORY_SIZE)
		rewards = np.zeros(self.episodes_num)	
		total_steps = 0
		rew=[]
		loss = []
		for episode in range(episodes_num):

			state = self.env.reset()
			state = np.reshape(state,[1,self.env.observation_space.shape[0]])
			
			episode_steps = 0
			episode_reward = 0
			total_cost = 0			
			self.EPSILON = max(self.min_epsilon,self.EPSILON*self.EPSILON_DECAY)
			while True:
				if np.random.rand(1) < self.EPSILON or total_steps < self.MINIBATCH_SIZE:
					a  = np.random.randint(0,2)
				else:
					a = self.session.run(self.main_predict,feed_dict={self.x:state})[0]

				next_state,reward,done,dummy = self.env.step(a)
				next_state = np.reshape(next_state,[1,self.env.observation_space.shape[0]])
				total_steps = total_steps + 1
				episode_steps = episode_steps + 1
				episode_reward = episode_reward +reward

				self.replay.add(np.reshape(np.array([state,a,reward,next_state,done]),[1,5]))

				if total_steps > self.MINIBATCH_SIZE:
						mini_batch = self.replay.sample(self.MINIBATCH_SIZE)
						max_Q = self.session.run(self.target_maxQ,feed_dict={self.x:np.vstack(mini_batch[:,3])})
						target = mini_batch[:,2] + self.DISCOUNT_FACTOR * max_Q * (1-mini_batch[:,4])
						_,cost,Q = self.session.run([self.train_op,self.loss,self.Q],feed_dict={self.x:np.vstack(mini_batch[:,0]),self.targetQ:np.reshape(target,(None)),self.actions:np.reshape(mini_batch[:,1],(None))})

			
						total_cost += cost
						
				if total_steps%self.TARGET_UPDATE_FREQ ==0:
					for i in self.target_weights.keys():
						assign_op = self.target_weights[i].assign(self.main_weights[i].value())
						self.session.run(assign_op)
						

				state = next_state

				if done or episode_steps > self.MAX_STEPS:
					break

			if episode >100:
				rew.append(episode_steps)
				rewards[episode] = episode_steps
				rew=rew[1:]
			else:
				rew.append(episode_steps)
				rewards[episode] = episode_steps
			loss.append( sum(rew)/100)
			print("Training: Episode = %d, Length = %f, Global step = %d" % (episode, sum(rew)/100, total_steps))
			summary.value.add(tag="episode length", simple_value=episode_steps)
			summary_writer.add_summary(summary, episode)

		return rewards
	 
		

	# Simple function to visually 'test' a policy
	def playPolicy(self):
		
		done = False
		steps = 0
		state = self.env.reset()
		state = np.reshape(state,[1,self.env.observation_space.shape[0]])
		
		# we assume the CartPole task to be solved if the pole remains upright for 200 steps
		while not done and steps < 200: 	
			#self.env.render()				
			q_vals = self.session.run(self.main_Qout, feed_dict={self.x: state})
			action = q_vals.argmax()
			state, _, done, _ = self.env.step(action)
			state = np.reshape(state,[1,self.env.observation_space.shape[0]])
			steps += 1
		
		return steps



if __name__ =="__main__":
	dqn = DQN('CartPole-v0')
	dqn.initialize_network()
	print("\nStarting training...\n")
	output = dqn.train()
	pd.DataFrame(output).to_csv("16_16_target.csv")

